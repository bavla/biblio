SN5 - Works on SNA from WoS till 2007

Networks created in January 2008 from WoS data using the 
program WoS2Pajek. 

number of works      =  193376
number of authors    =  75930
number of journals   =  14651
number of keywords   =  29267
number of records    =  8630

The dataset was used at the Viszards session of the
Sunbelt 2008 Conference.
